from django.urls import path, include
from rest_framework_nested import routers
from .views import PostViewSet, CommentViewSet
from rest_framework.authtoken.views import obtain_auth_token
from rest_framework.views import APIView
from rest_framework.response import Response

class LogoutView(APIView):
    def post(self, request):
        request.user.auth_token.delete()
        return Response(status=204)

router = routers.SimpleRouter()
router.register(r'posts', PostViewSet, basename='posts')

posts_router = routers.NestedSimpleRouter(router, r'posts', lookup='post')
posts_router.register(r'comments', CommentViewSet, basename='post-comments')

urlpatterns = [
    path('', include(router.urls)),
    path('', include(posts_router.urls)),
    path('login/', obtain_auth_token),
    path('logout/', LogoutView.as_view()),
]
